links = $("li a");
function extract(id, a) {return {href: a.href, text: a.text, className: a.className}};
extracted = links.map(extract);
JSON.stringify(extracted);